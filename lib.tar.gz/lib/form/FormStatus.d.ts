import React from "react";
export declare const FormStatus: React.ComponentType<{}>;
//# sourceMappingURL=FormStatus.d.ts.map