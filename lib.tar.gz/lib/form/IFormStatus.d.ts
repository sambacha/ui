/// <reference types="react" />
export interface IFormStatus {
    success: boolean;
    message?: React.ReactNode;
}
//# sourceMappingURL=IFormStatus.d.ts.map