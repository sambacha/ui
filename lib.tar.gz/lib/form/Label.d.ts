/// <reference types="react" />
export declare const Label: import("styled-components").StyledComponentClass<import("react").DetailedHTMLProps<import("react").LabelHTMLAttributes<HTMLLabelElement>, HTMLLabelElement>, import("../theme/ITheme").ITheme, import("react").DetailedHTMLProps<import("react").LabelHTMLAttributes<HTMLLabelElement>, HTMLLabelElement>>;
//# sourceMappingURL=Label.d.ts.map