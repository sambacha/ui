import { IFormContextType } from "./IFormContextType";
export declare const useFormContext: <TFormValues, TStatus>() => IFormContextType<TFormValues, TStatus>;
//# sourceMappingURL=useFormContext.d.ts.map