import * as React from "react";
export interface IFieldErrorProps {
    name: string;
    className?: string;
}
export declare class FieldError extends React.Component<IFieldErrorProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=FieldError.d.ts.map