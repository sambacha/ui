import React from "react";
export declare class SubmitButton extends React.Component<{
    children: string;
}> {
    private isClient;
    componentDidMount(): void;
    render(): JSX.Element;
}
//# sourceMappingURL=SubmitButton.d.ts.map