import * as React from "react";
interface ITooltipTextProps {
    textColor?: string;
}
export declare class TooltipText extends React.Component<ITooltipTextProps> {
    render(): JSX.Element;
}
export {};
//# sourceMappingURL=TooltipText.d.ts.map