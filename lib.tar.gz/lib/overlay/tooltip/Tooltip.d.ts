import * as React from "react";
import { ITooltipProps } from "./TooltipBase";
export declare class Tooltip extends React.Component<ITooltipProps> {
    static defaultProps: {
        offset: number;
    };
    render(): JSX.Element;
}
//# sourceMappingURL=Tooltip.d.ts.map