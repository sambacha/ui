import { ITheme } from "./ITheme";
import { IPalette } from "./IPalette";
export declare const createTheme: (palette: IPalette) => ITheme;
//# sourceMappingURL=createTheme.d.ts.map