export interface IPalette {
    WHITE: string;
    RED: string;
    GREEN: string;
    BLUE: string;
    ORANGE: string;
    DAWN: string;
    DUSK: string;
    DARK: string;
    GREEN_D5: string;
    BLUE_L5: string;
    BLUE_D5: string;
    DAWN_L5: string;
    DAWN_D5: string;
}
//# sourceMappingURL=IPalette.d.ts.map