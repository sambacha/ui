import { IPalette } from "./IPalette";
export declare const createPalette: () => IPalette;
//# sourceMappingURL=createPalette.d.ts.map