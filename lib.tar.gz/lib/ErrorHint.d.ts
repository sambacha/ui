import * as React from "react";
import { IErrorIconProps } from "./icon/ErrorIcon";
interface IErrorHintProps extends IErrorIconProps {
}
export declare class ErrorHint extends React.Component<IErrorHintProps> {
    render(): JSX.Element;
}
export {};
//# sourceMappingURL=ErrorHint.d.ts.map