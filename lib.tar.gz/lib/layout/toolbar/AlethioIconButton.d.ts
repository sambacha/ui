import * as React from "react";
export interface IAlethioIconButtonProps {
}
export declare class AlethioIconButton extends React.Component<IAlethioIconButtonProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=AlethioIconButton.d.ts.map