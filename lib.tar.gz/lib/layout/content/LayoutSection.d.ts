import * as React from "react";
export interface ILayoutSectionProps {
    useWrapper?: boolean;
}
export declare class LayoutSection extends React.Component<ILayoutSectionProps> {
    render(): JSX.Element | null;
}
//# sourceMappingURL=LayoutSection.d.ts.map