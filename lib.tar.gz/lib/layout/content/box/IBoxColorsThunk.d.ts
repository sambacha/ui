import { IBoxColors } from "./IBoxColors";
export interface IBoxColorsThunk<TTheme> {
    (theme: TTheme): IBoxColors;
}
//# sourceMappingURL=IBoxColorsThunk.d.ts.map