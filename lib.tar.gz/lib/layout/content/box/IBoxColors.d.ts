export interface IBoxColors {
    text: string;
    background?: string;
    border?: string;
}
//# sourceMappingURL=IBoxColors.d.ts.map