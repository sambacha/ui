export interface IViewportSize {
    height: number;
    width: number;
}
export declare const useViewportSize: () => IViewportSize;
//# sourceMappingURL=useViewportSize.d.ts.map