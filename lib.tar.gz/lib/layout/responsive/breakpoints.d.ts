export declare const breakpoints: {
    xsMax: number;
    sMax: number;
    mMax: number;
    lMax: number;
    xlMax: number;
};
//# sourceMappingURL=breakpoints.d.ts.map