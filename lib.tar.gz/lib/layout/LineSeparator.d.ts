/// <reference types="react" />
export declare const LineSeparator: import("styled-components").StyledComponentClass<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHRElement>, HTMLHRElement>, import("../theme/ITheme").ITheme, import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLHRElement>, HTMLHRElement>>;
//# sourceMappingURL=LineSeparator.d.ts.map