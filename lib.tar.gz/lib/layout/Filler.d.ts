/// <reference types="react" />
interface IFillerProps {
    className?: string;
}
export declare const Filler: import("styled-components").StyledComponentClass<IFillerProps, import("../theme/ITheme").ITheme, IFillerProps & import("react").ClassAttributes<HTMLDivElement> & import("react").HTMLAttributes<HTMLDivElement>>;
export {};
//# sourceMappingURL=Filler.d.ts.map