/// <reference types="react" />
export interface IBarProps {
    sticky?: boolean;
    zIndex?: number;
}
export declare const Bar: import("styled-components").StyledComponentClass<IBarProps, import("../theme/ITheme").ITheme, IBarProps & import("react").ClassAttributes<HTMLDivElement> & import("react").HTMLAttributes<HTMLDivElement>>;
//# sourceMappingURL=Bar.d.ts.map