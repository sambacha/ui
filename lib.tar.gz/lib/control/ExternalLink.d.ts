import React, { AnchorHTMLAttributes } from "react";
interface IExternalLinkProps {
}
export declare class ExternalLink extends React.Component<AnchorHTMLAttributes<HTMLAnchorElement> & IExternalLinkProps> {
    render(): JSX.Element;
}
export {};
//# sourceMappingURL=ExternalLink.d.ts.map