export declare enum LoadStatus {
    NotLoaded = 0,
    Loaded = 1,
    Error = 2
}
//# sourceMappingURL=LoadStatus.d.ts.map