export {};
//# sourceMappingURL=Cursor.d.ts.map