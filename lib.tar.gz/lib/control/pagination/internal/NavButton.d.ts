export {};
//# sourceMappingURL=NavButton.d.ts.map