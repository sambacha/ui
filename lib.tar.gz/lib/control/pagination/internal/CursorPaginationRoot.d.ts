export {};
//# sourceMappingURL=CursorPaginationRoot.d.ts.map