export {};
//# sourceMappingURL=Spinner.d.ts.map