export {};
//# sourceMappingURL=GridData.d.ts.map