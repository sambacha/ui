export {};
//# sourceMappingURL=GridWrapper.d.ts.map