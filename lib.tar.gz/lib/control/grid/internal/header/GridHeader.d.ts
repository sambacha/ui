import * as React from "react";
export interface IGridHeaderExtraElements {
    left?: React.ReactNode;
    right?: React.ReactNode;
}
//# sourceMappingURL=GridHeader.d.ts.map