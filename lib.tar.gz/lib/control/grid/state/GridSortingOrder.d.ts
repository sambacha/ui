export declare enum GridSortingOrder {
    Ascending = 0,
    Descending = 1,
    Default = 2
}
//# sourceMappingURL=GridSortingOrder.d.ts.map