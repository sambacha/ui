/// <reference types="react" />
export declare const InputBase: import("styled-components").StyledComponentClass<import("react").ClassAttributes<HTMLInputElement> & import("react").InputHTMLAttributes<HTMLInputElement> & {
    alignRight?: boolean | undefined;
}, import("../theme/ITheme").ITheme, import("react").ClassAttributes<HTMLInputElement> & import("react").InputHTMLAttributes<HTMLInputElement> & {
    alignRight?: boolean | undefined;
}>;
//# sourceMappingURL=InputBase.d.ts.map