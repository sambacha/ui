export declare enum AccordionItemContentStatus {
    NotLoaded = 0,
    Loaded = 1,
    Error = 2
}
//# sourceMappingURL=AccordionItemContentStatus.d.ts.map