/// <reference types="react" />
export interface IAccordionItemConfig {
    priority?: number;
    children?: React.ReactNode;
    content?(): Promise<React.ReactElement<{}>>;
}
//# sourceMappingURL=IAccordionItemConfig.d.ts.map