import * as React from "react";
interface IExpanderIconProps {
    expanded: boolean;
    color: string;
    backgroundColor: string;
}
export declare class ExpanderBaseIcon extends React.PureComponent<IExpanderIconProps> {
    render(): JSX.Element;
}
export {};
//# sourceMappingURL=ExpanderBaseIcon.d.ts.map