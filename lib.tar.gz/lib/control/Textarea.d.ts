/// <reference types="react" />
export declare const Textarea: import("styled-components").StyledComponentClass<import("react").DetailedHTMLProps<import("react").TextareaHTMLAttributes<HTMLTextAreaElement>, HTMLTextAreaElement>, import("../theme/ITheme").ITheme, import("react").ClassAttributes<HTMLTextAreaElement> & import("react").TextareaHTMLAttributes<HTMLTextAreaElement> & import("react").ClassAttributes<HTMLInputElement> & import("react").InputHTMLAttributes<HTMLInputElement> & {
    alignRight?: boolean | undefined;
}>;
//# sourceMappingURL=Textarea.d.ts.map