import * as React from "react";
export interface IUsdValueProps {
    value: number;
    locale: string | undefined;
}
export declare class UsdValue extends React.Component<IUsdValueProps> {
    render(): string;
}
//# sourceMappingURL=UsdValue.d.ts.map