export interface IStackBarBubbleProps {
    color: string;
    className?: string;
}
//# sourceMappingURL=StackBarBubble.d.ts.map