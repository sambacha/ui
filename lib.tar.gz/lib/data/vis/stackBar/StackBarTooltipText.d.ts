import * as React from "react";
export interface IStackBarTooltipTextProps {
    bubbleColor: string;
}
export declare class StackBarTooltipText extends React.Component<IStackBarTooltipTextProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=StackBarTooltipText.d.ts.map