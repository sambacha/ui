import * as React from "react";
interface IShortDateProps {
    timestamp: number;
    locale: string;
}
export declare class ShortDate extends React.PureComponent<IShortDateProps> {
    render(): string;
}
export {};
//# sourceMappingURL=ShortDate.d.ts.map