import * as React from "react";
interface IGasPercentageBoxProps {
}
export declare const GasPercentageBox: React.StatelessComponent<IGasPercentageBoxProps>;
export {};
//# sourceMappingURL=GasPercentageBox.d.ts.map