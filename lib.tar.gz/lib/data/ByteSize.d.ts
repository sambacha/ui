import * as React from "react";
export interface IByteSizeProps {
    children: number;
    locale: string;
    format: string;
}
export declare class ByteSize extends React.Component<IByteSizeProps> {
    render(): string;
}
//# sourceMappingURL=ByteSize.d.ts.map