export interface IClipboard {
    copy(data: string): void;
}
//# sourceMappingURL=IClipboard.d.ts.map