import * as React from "react";
export interface IStringDataProps {
    children: string;
}
export declare class StringData extends React.Component<IStringDataProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=StringData.d.ts.map