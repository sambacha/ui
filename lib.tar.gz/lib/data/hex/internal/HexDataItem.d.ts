export {};
//# sourceMappingURL=HexDataItem.d.ts.map