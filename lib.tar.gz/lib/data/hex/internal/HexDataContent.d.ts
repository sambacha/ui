export {};
//# sourceMappingURL=HexDataContent.d.ts.map