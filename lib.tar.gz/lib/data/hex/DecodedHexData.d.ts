import * as React from "react";
import { IClipboard } from "../IClipboard";
interface IDecodedHexDataProps {
    data: string;
    clipboard?: IClipboard;
}
export declare class DecodedHexData extends React.PureComponent<IDecodedHexDataProps> {
    render(): JSX.Element;
}
export {};
//# sourceMappingURL=DecodedHexData.d.ts.map