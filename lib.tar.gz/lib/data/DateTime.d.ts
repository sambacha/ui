import * as React from "react";
interface IDateTimeProps {
    timestamp: number;
    locale: string | undefined;
}
export declare class DateTime extends React.PureComponent<IDateTimeProps> {
    render(): string;
}
export {};
//# sourceMappingURL=DateTime.d.ts.map