import * as React from "react";
export interface ISpinnerLiteProps {
    size?: number;
}
export declare class SpinnerLite extends React.Component<ISpinnerLiteProps> {
    static defaultProps: {
        size: number;
    };
    render(): JSX.Element;
}
//# sourceMappingURL=SpinnerLite.d.ts.map