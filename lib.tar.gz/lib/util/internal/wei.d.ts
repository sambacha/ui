export {};
//# sourceMappingURL=wei.d.ts.map