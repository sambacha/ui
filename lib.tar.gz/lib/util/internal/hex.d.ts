export {};
//# sourceMappingURL=hex.d.ts.map