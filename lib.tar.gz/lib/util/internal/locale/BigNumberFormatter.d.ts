export {};
//# sourceMappingURL=BigNumberFormatter.d.ts.map