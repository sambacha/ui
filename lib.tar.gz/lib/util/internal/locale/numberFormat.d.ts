export {};
//# sourceMappingURL=numberFormat.d.ts.map