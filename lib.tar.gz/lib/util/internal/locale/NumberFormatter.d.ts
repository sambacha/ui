export {};
//# sourceMappingURL=NumberFormatter.d.ts.map