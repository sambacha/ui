export {};
//# sourceMappingURL=DifficultyFormatter.d.ts.map