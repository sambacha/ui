import { BigNumber as BN } from "bignumber.js";
export declare type BigNumber = BN;
export declare type Format = BN.Format;
//# sourceMappingURL=BigNumber.d.ts.map