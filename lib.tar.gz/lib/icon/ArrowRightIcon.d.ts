import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IArrowRightIconProps extends ISvgIconProps {
}
export declare class ArrowRightIcon extends React.Component<IArrowRightIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=ArrowRightIcon.d.ts.map