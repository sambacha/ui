import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IIdentityIconProps extends ISvgIconProps {
}
export declare class IdentityIcon extends React.Component<IIdentityIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=IdentityIcon.d.ts.map