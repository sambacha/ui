import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface ITriangleLeftIconProps extends ISvgIconProps {
}
export declare class TriangleLeftIcon extends React.Component<ITriangleLeftIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=TriangleLeftIcon.d.ts.map