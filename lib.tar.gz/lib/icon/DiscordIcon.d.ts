import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IDiscordIconProps extends ISvgIconProps {
}
export declare class DiscordIcon extends React.Component<IDiscordIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=DiscordIcon.d.ts.map