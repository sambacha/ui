import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface ICopyIconProps extends ISvgIconProps {
}
export declare class CopyIcon extends React.Component<ICopyIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=CopyIcon.d.ts.map