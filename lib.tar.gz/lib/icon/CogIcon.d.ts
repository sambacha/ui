import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface ICogIconProps extends ISvgIconProps {
}
export declare class CogIcon extends React.Component<ICogIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=CogIcon.d.ts.map