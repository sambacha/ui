import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface ITableIconProps extends ISvgIconProps {
}
export declare class TableIcon extends React.Component<ITableIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=TableIcon.d.ts.map