import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IResetIconProps extends ISvgIconProps {
}
export declare class ResetIcon extends React.Component<IResetIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=ResetIcon.d.ts.map