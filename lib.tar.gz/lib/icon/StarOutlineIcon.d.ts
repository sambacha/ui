import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IStarOutlineIconProps extends ISvgIconProps {
}
export declare class StarOutlineIcon extends React.Component<IStarOutlineIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=StarOutlineIcon.d.ts.map