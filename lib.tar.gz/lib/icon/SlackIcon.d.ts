import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface ISlackIconProps extends ISvgIconProps {
}
export declare class SlackIcon extends React.Component<ISlackIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=SlackIcon.d.ts.map