import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface ILanguageIconProps extends ISvgIconProps {
}
export declare class LanguageIcon extends React.Component<ILanguageIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=LanguageIcon.d.ts.map