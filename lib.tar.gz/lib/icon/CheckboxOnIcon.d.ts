import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface ICheckboxOnIconProps extends ISvgIconProps {
}
export declare class CheckboxOnIcon extends React.Component<ICheckboxOnIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=CheckboxOnIcon.d.ts.map