import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IAlethioReportsInvertedIconProps extends ISvgIconProps {
}
export declare class AlethioReportsInvertedIcon extends React.Component<IAlethioReportsInvertedIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=AlethioReportsInvertedIcon.d.ts.map