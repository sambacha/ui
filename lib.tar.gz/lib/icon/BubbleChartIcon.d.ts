import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IBubbleChartIconProps extends ISvgIconProps {
}
export declare class BubbleChartIcon extends React.Component<IBubbleChartIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=BubbleChartIcon.d.ts.map