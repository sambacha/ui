import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IAlethioMonitoringIconProps extends ISvgIconProps {
}
export declare class AlethioMonitoringIcon extends React.PureComponent<IAlethioMonitoringIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=AlethioMonitoringIcon.d.ts.map