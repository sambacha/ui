import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IAlethioIconProps extends ISvgIconProps {
}
export declare class AlethioIcon extends React.PureComponent<IAlethioIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=AlethioIcon.d.ts.map