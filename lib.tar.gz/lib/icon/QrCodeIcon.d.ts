import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IQrCodeIconProps extends ISvgIconProps {
}
export declare class QrCodeIcon extends React.Component<IQrCodeIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=QrCodeIcon.d.ts.map