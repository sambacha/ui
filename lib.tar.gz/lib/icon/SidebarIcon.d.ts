import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface ISidebarIconProps extends ISvgIconProps {
}
export declare class SidebarIcon extends React.Component<ISidebarIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=SidebarIcon.d.ts.map