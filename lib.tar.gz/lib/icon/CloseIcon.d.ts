import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface ICloseIconProps extends ISvgIconProps {
}
export declare class CloseIcon extends React.Component<ICloseIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=CloseIcon.d.ts.map