import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IOpenInBrowserIconProps extends ISvgIconProps {
}
export declare class OpenInBrowserIcon extends React.Component<IOpenInBrowserIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=OpenInBrowserIcon.d.ts.map