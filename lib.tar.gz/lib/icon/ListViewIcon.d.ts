import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IListViewIconProps extends ISvgIconProps {
}
export declare class ListViewIcon extends React.Component<IListViewIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=ListViewIcon.d.ts.map