import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IGridViewIconProps extends ISvgIconProps {
}
export declare class GridViewIcon extends React.Component<IGridViewIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=GridViewIcon.d.ts.map