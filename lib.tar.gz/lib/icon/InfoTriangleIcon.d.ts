import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IInfoTriangleIconProps extends ISvgIconProps {
}
export declare class InfoTriangleIcon extends React.Component<IInfoTriangleIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=InfoTriangleIcon.d.ts.map