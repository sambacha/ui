import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IErrorSmallIconProps extends ISvgIconProps {
}
export declare class ErrorSmallIcon extends React.PureComponent<IErrorSmallIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=ErrorSmallIcon.d.ts.map