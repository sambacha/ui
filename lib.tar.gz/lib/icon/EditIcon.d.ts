import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IEditIconProps extends ISvgIconProps {
}
export declare class EditIcon extends React.Component<IEditIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=EditIcon.d.ts.map