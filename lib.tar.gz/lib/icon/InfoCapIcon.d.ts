import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IInfoCapIconProps extends ISvgIconProps {
}
export declare class InfoCapIcon extends React.Component<IInfoCapIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=InfoCapIcon.d.ts.map