import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IArrowUpIconProps extends ISvgIconProps {
}
export declare class ArrowUpIcon extends React.Component<IArrowUpIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=ArrowUpIcon.d.ts.map