import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface ICheckboxOffIconProps extends ISvgIconProps {
}
export declare class CheckboxOffIcon extends React.Component<ICheckboxOffIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=CheckboxOffIcon.d.ts.map