import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IMsgCountOutSmallIconProps extends ISvgIconProps {
}
export declare class MsgCountOutSmallIcon extends React.Component<IMsgCountOutSmallIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=MsgCountOutSmallIcon.d.ts.map