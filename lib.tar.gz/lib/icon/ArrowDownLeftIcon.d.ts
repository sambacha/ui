import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IArrowDownLeftIconProps extends ISvgIconProps {
}
export declare class ArrowDownLeftIcon extends React.Component<IArrowDownLeftIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=ArrowDownLeftIcon.d.ts.map