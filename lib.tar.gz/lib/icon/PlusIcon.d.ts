import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IPlusIconProps extends ISvgIconProps {
}
export declare class PlusIcon extends React.Component<IPlusIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=PlusIcon.d.ts.map