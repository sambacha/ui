import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IChatBubbleIconProps extends ISvgIconProps {
}
export declare class ChatBubbleIcon extends React.Component<IChatBubbleIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=ChatBubbleIcon.d.ts.map