import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IMoreVertIconProps extends ISvgIconProps {
}
export declare class MoreVertIcon extends React.Component<IMoreVertIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=MoreVertIcon.d.ts.map