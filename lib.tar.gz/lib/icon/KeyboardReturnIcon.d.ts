import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IKeyboardReturnIconProps extends ISvgIconProps {
}
export declare class KeyboardReturnIcon extends React.Component<IKeyboardReturnIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=KeyboardReturnIcon.d.ts.map