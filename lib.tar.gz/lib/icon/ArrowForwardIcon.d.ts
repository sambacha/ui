import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IArrowForwardIconProps extends ISvgIconProps {
}
export declare class ArrowForwardIcon extends React.Component<IArrowForwardIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=ArrowForwardIcon.d.ts.map