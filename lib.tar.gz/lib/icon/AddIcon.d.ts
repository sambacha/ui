import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IAddIconProps extends ISvgIconProps {
}
export declare class AddIcon extends React.Component<IAddIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=AddIcon.d.ts.map