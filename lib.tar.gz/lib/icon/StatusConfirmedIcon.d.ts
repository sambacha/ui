import * as React from "react";
import { IStatusOkIconProps } from "./StatusOkIcon";
interface IStatusConfirmedIconProps extends IStatusOkIconProps {
}
export declare class StatusConfirmedIcon extends React.PureComponent<IStatusConfirmedIconProps> {
    render(): JSX.Element;
}
export {};
//# sourceMappingURL=StatusConfirmedIcon.d.ts.map