import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface ICloseSmallIconProps extends ISvgIconProps {
}
export declare class CloseSmallIcon extends React.Component<ICloseSmallIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=CloseSmallIcon.d.ts.map