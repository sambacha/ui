import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IPlayIconProps extends ISvgIconProps {
}
export declare class PlayIcon extends React.Component<IPlayIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=PlayIcon.d.ts.map