import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface ILogoutIconProps extends ISvgIconProps {
}
export declare class LogoutIcon extends React.Component<ILogoutIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=LogoutIcon.d.ts.map