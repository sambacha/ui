import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface ILayoutIconProps extends ISvgIconProps {
}
export declare class LayoutIcon extends React.Component<ILayoutIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=LayoutIcon.d.ts.map