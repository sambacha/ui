import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IMsgCountOutIconProps extends ISvgIconProps {
}
export declare class MsgCountOutIcon extends React.Component<IMsgCountOutIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=MsgCountOutIcon.d.ts.map