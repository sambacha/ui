import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IPlusLargeIconProps extends ISvgIconProps {
}
export declare class PlusLargeIcon extends React.Component<IPlusLargeIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=PlusLargeIcon.d.ts.map