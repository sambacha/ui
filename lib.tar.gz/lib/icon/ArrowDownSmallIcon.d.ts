import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IArrowDownSmallIconProps extends ISvgIconProps {
}
export declare class ArrowDownSmallIcon extends React.Component<IArrowDownSmallIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=ArrowDownSmallIcon.d.ts.map