import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface ITriangleDownIconProps extends ISvgIconProps {
}
export declare class TriangleDownIcon extends React.Component<ITriangleDownIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=TriangleDownIcon.d.ts.map