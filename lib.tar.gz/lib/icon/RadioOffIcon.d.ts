import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IRadioOffIconProps extends ISvgIconProps {
}
export declare class RadioOffIcon extends React.Component<IRadioOffIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=RadioOffIcon.d.ts.map