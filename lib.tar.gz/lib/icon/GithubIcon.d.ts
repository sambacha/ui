import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IGithubIconProps extends ISvgIconProps {
}
export declare class GithubIcon extends React.Component<IGithubIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=GithubIcon.d.ts.map