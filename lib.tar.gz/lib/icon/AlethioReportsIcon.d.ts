import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IAlethioReportsIconProps extends ISvgIconProps {
}
export declare class AlethioReportsIcon extends React.PureComponent<IAlethioReportsIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=AlethioReportsIcon.d.ts.map