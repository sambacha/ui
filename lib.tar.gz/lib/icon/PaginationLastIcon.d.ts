import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IPaginationLastIconProps extends ISvgIconProps {
}
export declare class PaginationLastIcon extends React.Component<IPaginationLastIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=PaginationLastIcon.d.ts.map