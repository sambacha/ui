import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IMsgCountPendingSmallIconProps extends ISvgIconProps {
}
export declare class MsgCountPendingSmallIcon extends React.Component<IMsgCountPendingSmallIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=MsgCountPendingSmallIcon.d.ts.map