import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IListIconProps extends ISvgIconProps {
}
export declare class ListIcon extends React.Component<IListIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=ListIcon.d.ts.map