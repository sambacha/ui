import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface ITriangleRightIconProps extends ISvgIconProps {
}
export declare class TriangleRightIcon extends React.Component<ITriangleRightIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=TriangleRightIcon.d.ts.map