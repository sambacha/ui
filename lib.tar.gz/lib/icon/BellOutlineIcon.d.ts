import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IBellOutlineIconProps extends ISvgIconProps {
}
export declare class BellOutlineIcon extends React.Component<IBellOutlineIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=BellOutlineIcon.d.ts.map