import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IArrowUpRightInvertedIconProps extends ISvgIconProps {
}
export declare class ArrowUpRightInvertedIcon extends React.Component<IArrowUpRightInvertedIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=ArrowUpRightInvertedIcon.d.ts.map