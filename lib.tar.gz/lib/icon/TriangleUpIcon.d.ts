import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface ITriangleUpIconProps extends ISvgIconProps {
}
export declare class TriangleUpIcon extends React.Component<ITriangleUpIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=TriangleUpIcon.d.ts.map