import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IBriefcaseIconProps extends ISvgIconProps {
}
export declare class BriefcaseIcon extends React.Component<IBriefcaseIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=BriefcaseIcon.d.ts.map