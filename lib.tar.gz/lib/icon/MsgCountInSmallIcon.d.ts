import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IMsgCountInSmallIconProps extends ISvgIconProps {
}
export declare class MsgCountInSmallIcon extends React.Component<IMsgCountInSmallIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=MsgCountInSmallIcon.d.ts.map