import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface ICalendarIconProps extends ISvgIconProps {
}
export declare class CalendarIcon extends React.Component<ICalendarIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=CalendarIcon.d.ts.map