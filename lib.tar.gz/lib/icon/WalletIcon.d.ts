import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IWalletIconProps extends ISvgIconProps {
}
export declare class WalletIcon extends React.PureComponent<IWalletIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=WalletIcon.d.ts.map