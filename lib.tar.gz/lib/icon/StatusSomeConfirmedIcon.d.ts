import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
interface IStatusSomeConfirmedIconProps extends ISvgIconProps {
}
export declare class StatusSomeConfirmedIcon extends React.PureComponent<IStatusSomeConfirmedIconProps> {
    render(): JSX.Element;
}
export {};
//# sourceMappingURL=StatusSomeConfirmedIcon.d.ts.map