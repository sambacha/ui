import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IMsgCountInIconProps extends ISvgIconProps {
}
export declare class MsgCountInIcon extends React.Component<IMsgCountInIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=MsgCountInIcon.d.ts.map