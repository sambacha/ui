import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IEmptyIconProps extends ISvgIconProps {
}
export declare class EmptyIcon extends React.Component<IEmptyIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=EmptyIcon.d.ts.map