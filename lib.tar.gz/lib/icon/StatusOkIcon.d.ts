import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IStatusOkIconProps extends ISvgIconProps {
}
export declare class StatusOkIcon extends React.PureComponent<IStatusOkIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=StatusOkIcon.d.ts.map