import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IHamburgerIconProps extends ISvgIconProps {
}
export declare class HamburgerIcon extends React.Component<IHamburgerIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=HamburgerIcon.d.ts.map