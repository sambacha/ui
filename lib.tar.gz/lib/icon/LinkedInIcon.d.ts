import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface ILinkedInIconProps extends ISvgIconProps {
}
export declare class LinkedInIcon extends React.Component<ILinkedInIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=LinkedInIcon.d.ts.map