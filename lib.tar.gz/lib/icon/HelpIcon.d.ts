import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IHelpIconProps extends ISvgIconProps {
}
export declare class HelpIcon extends React.Component<IHelpIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=HelpIcon.d.ts.map