import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IHamburgerSkinnyIconProps extends ISvgIconProps {
}
export declare class HamburgerSkinnyIcon extends React.Component<IHamburgerSkinnyIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=HamburgerSkinnyIcon.d.ts.map