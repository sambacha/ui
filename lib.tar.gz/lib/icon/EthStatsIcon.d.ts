import * as React from "react";
export interface IEthStatsIconProps {
    color?: string;
    size: number;
}
export declare class EthStatsIcon extends React.PureComponent<IEthStatsIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=EthStatsIcon.d.ts.map