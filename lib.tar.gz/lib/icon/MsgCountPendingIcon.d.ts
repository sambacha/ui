import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IMsgCountPendingIconProps extends ISvgIconProps {
}
export declare class MsgCountPendingIcon extends React.Component<IMsgCountPendingIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=MsgCountPendingIcon.d.ts.map