import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface ITrashOutlineIconProps extends ISvgIconProps {
}
export declare class TrashOutlineIcon extends React.Component<ITrashOutlineIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=TrashOutlineIcon.d.ts.map