import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
interface IDefiIconProps extends ISvgIconProps {
}
export declare class DefiIcon extends React.PureComponent<IDefiIconProps> {
    render(): JSX.Element;
}
export {};
//# sourceMappingURL=DefiIcon.d.ts.map