import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IArrowUpSmallIconProps extends ISvgIconProps {
}
export declare class ArrowUpSmallIcon extends React.Component<IArrowUpSmallIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=ArrowUpSmallIcon.d.ts.map