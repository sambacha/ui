import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IMediumIconProps extends ISvgIconProps {
}
export declare class MediumIcon extends React.Component<IMediumIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=MediumIcon.d.ts.map