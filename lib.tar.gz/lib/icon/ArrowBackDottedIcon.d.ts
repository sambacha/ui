import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IArrowBackDottedIconProps extends ISvgIconProps {
}
export declare class ArrowBackDottedIcon extends React.Component<IArrowBackDottedIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=ArrowBackDottedIcon.d.ts.map