import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IArrowLeftIconProps extends ISvgIconProps {
}
export declare class ArrowLeftIcon extends React.Component<IArrowLeftIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=ArrowLeftIcon.d.ts.map