import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IArrowBackwardIconProps extends ISvgIconProps {
}
export declare class ArrowBackwardIcon extends React.Component<IArrowBackwardIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=ArrowBackwardIcon.d.ts.map