import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IMailIconProps extends ISvgIconProps {
}
export declare class MailIcon extends React.Component<IMailIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=MailIcon.d.ts.map