import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface ITwitterIconProps extends ISvgIconProps {
}
export declare class TwitterIcon extends React.Component<ITwitterIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=TwitterIcon.d.ts.map