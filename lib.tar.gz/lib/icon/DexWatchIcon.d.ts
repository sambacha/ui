import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IDexWatchIconProps extends ISvgIconProps {
}
export declare class DexWatchIcon extends React.Component<IDexWatchIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=DexWatchIcon.d.ts.map