import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface ISwitchIconProps extends ISvgIconProps {
}
export declare class SwitchIcon extends React.Component<ISwitchIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=SwitchIcon.d.ts.map