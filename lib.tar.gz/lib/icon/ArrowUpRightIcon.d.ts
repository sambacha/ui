import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IArrowUpRightIconProps extends ISvgIconProps {
}
export declare class ArrowUpRightIcon extends React.Component<IArrowUpRightIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=ArrowUpRightIcon.d.ts.map