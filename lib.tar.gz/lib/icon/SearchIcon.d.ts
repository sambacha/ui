import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface ISearchIconProps extends ISvgIconProps {
}
export declare class SearchIcon extends React.Component<ISearchIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=SearchIcon.d.ts.map