import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IArrowForwardDottedIconProps extends ISvgIconProps {
}
export declare class ArrowForwardDottedIcon extends React.Component<IArrowForwardDottedIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=ArrowForwardDottedIcon.d.ts.map