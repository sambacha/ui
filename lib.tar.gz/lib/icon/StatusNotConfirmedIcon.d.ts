import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
interface IStatusNotConfirmedIconProps extends ISvgIconProps {
}
export declare class StatusNotConfirmedIcon extends React.PureComponent<IStatusNotConfirmedIconProps> {
    render(): JSX.Element;
}
export {};
//# sourceMappingURL=StatusNotConfirmedIcon.d.ts.map