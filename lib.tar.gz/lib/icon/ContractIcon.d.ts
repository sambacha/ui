import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IContractIconProps extends ISvgIconProps {
}
export declare class ContractIcon extends React.Component<IContractIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=ContractIcon.d.ts.map