import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IRadioOnIconProps extends ISvgIconProps {
}
export declare class RadioOnIcon extends React.Component<IRadioOnIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=RadioOnIcon.d.ts.map