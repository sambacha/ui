import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IPaginationFirstIconProps extends ISvgIconProps {
}
export declare class PaginationFirstIcon extends React.Component<IPaginationFirstIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=PaginationFirstIcon.d.ts.map