import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IInfoIconProps extends ISvgIconProps {
}
export declare class InfoIcon extends React.PureComponent<IInfoIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=InfoIcon.d.ts.map