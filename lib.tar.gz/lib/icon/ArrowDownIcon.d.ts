import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface IArrowDownIconProps extends ISvgIconProps {
}
export declare class ArrowDownIcon extends React.Component<IArrowDownIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=ArrowDownIcon.d.ts.map