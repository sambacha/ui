import * as React from "react";
import { ISvgIconProps } from "../util/react/SvgIcon";
export interface ILoginIconProps extends ISvgIconProps {
}
export declare class LoginIcon extends React.Component<ILoginIconProps> {
    render(): JSX.Element;
}
//# sourceMappingURL=LoginIcon.d.ts.map